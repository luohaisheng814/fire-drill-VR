using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace VRFireDrill
{
    /// <summary>
    /// 排序题右侧的答案槽位（1、2、3…）。点击已填入的槽位可撤销该位置及之后的选择。
    /// </summary>
    public class QuizAnswerSlot : MonoBehaviour
    {
        [Header("UI")]
        public TextMeshProUGUI label;
        public Button button;
        public Image background;

        [Header("颜色")]
        public Color emptyColor = new Color(0.20f, 0.20f, 0.22f, 0.9f);
        public Color filledColor = new Color(0.16f, 0.33f, 0.55f, 0.95f);
        public Color errorColor = new Color(0.65f, 0.12f, 0.12f, 0.95f);

        int _slotIndex;
        QuizManager _manager;

        public void Setup(int slotIndex, QuizManager manager)
        {
            _slotIndex = slotIndex;
            _manager = manager;
            if (button == null) button = GetComponent<Button>();
            if (button != null)
            {
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(OnClick);
            }
            SetContent($"{slotIndex + 1}. ________", false);
        }

        public void SetContent(string text, bool filled)
        {
            if (label != null) label.text = text;
            if (background != null) background.color = filled ? filledColor : emptyColor;
        }

        /// <summary>Button OnClick 直接绑这个方法</summary>
        public void OnClick() => _manager?.RemoveAt(_slotIndex);

        public void FlashError()
        {
            if (background == null) return;
            StopAllCoroutines();
            StartCoroutine(Flash());
        }

        IEnumerator Flash()
        {
            background.color = errorColor;
            yield return new WaitForSeconds(0.35f);
            background.color = emptyColor;
        }
    }
}
