using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace VRFireDrill
{
    /// <summary>
    /// 消防安全步骤排序题。
    /// 交互：手柄射线点击左侧步骤条目 → 自动填入右侧 1、2、3… 槽位；点击已填入的槽位可撤销。
    /// 填满自动判定；有 30 秒（可配置）限时，超时即失败。
    /// </summary>
    public class QuizManager : MonoBehaviour
    {
        [Header("数据")]
        public QuizData data;

        [Header("面板")]
        public GameObject panel;

        [Header("UI 引用")]
        public TextMeshProUGUI questionText;
        public TextMeshProUGUI timerText;
        public TextMeshProUGUI feedbackText;
        public TextMeshProUGUI progressText;

        [Header("自动生成用预制体")]
        public QuizStepItem stepItemPrefab;
        public Transform stepItemContainer;
        public QuizAnswerSlot slotPrefab;
        public Transform slotContainer;

        [Header("规则")]
        public float timeLimit = 30f;
        public bool shuffle = true;
        [Tooltip("答错是否直接失败；false = 可以一直改到超时")]
        public bool failOnWrongAnswer = false;
        public int maxWrongAttempts = 0;   // 0 = 不限

        [Header("事件")]
        public UnityEvent onPassed = new UnityEvent();
        public UnityEvent<string> onFailed = new UnityEvent<string>();

        readonly List<QuizStepItem> _items = new List<QuizStepItem>();
        readonly List<QuizAnswerSlot> _slots = new List<QuizAnswerSlot>();
        readonly List<int> _answer = new List<int>();   // _answer[槽位] = 步骤索引

        readonly CountdownTimer _timer = new CountdownTimer();
        bool _open;
        int _wrongCount;

        public bool IsOpen => _open;

        // ------------------------------------------------------------ 生命周期

        void Awake()
        {
            _timer.onTick += HandleTick;
            _timer.onFinished += () => { if (_open) Fail(data != null ? data.timeoutMessage : "排序超时，练习失败。"); };
        }

        void Start()
        {
            if (panel != null) panel.SetActive(false);
        }

        // ------------------------------------------------------------ 开关

        public void Open()
        {
            if (_open) return;
            _open = true;
            _wrongCount = 0;
            _answer.Clear();
            BuildUI();
            if (panel != null) panel.SetActive(true);
            if (feedbackText != null) feedbackText.text = "";
            _timer.Start(timeLimit);
        }

        public void Close()
        {
            _open = false;
            _timer.Stop();
            if (panel != null) panel.SetActive(false);
        }

        // ------------------------------------------------------------ 生成 UI

        void BuildUI()
        {
            if (data == null) { Debug.LogError("[QuizManager] 未指定 QuizData"); return; }

            ClearContainer(stepItemContainer);
            ClearContainer(slotContainer);
            _items.Clear();
            _slots.Clear();

            if (questionText != null) questionText.text = data.question;

            // 乱序的步骤条目
            var order = Enumerable.Range(0, data.steps.Count).ToList();
            if (shuffle) order = order.OrderBy(_ => Random.value).ToList();

            foreach (int idx in order)
            {
                if (stepItemPrefab == null || stepItemContainer == null) continue;
                var item = Instantiate(stepItemPrefab, stepItemContainer);
                item.Setup(idx, data.steps[idx].text, this);
                _items.Add(item);
            }

            // 答案槽位
            for (int i = 0; i < data.steps.Count; i++)
            {
                if (slotPrefab == null || slotContainer == null) continue;
                var slot = Instantiate(slotPrefab, slotContainer);
                slot.Setup(i, this);
                _slots.Add(slot);
            }

            RefreshUI();
        }

        void ClearContainer(Transform t)
        {
            if (t == null) return;
            for (int i = t.childCount - 1; i >= 0; i--)
            {
                var child = t.GetChild(i);
                if (Application.isPlaying) Destroy(child.gameObject);
                else DestroyImmediate(child.gameObject);
            }
        }

        // ------------------------------------------------------------ 交互

        /// <summary>点击左侧步骤条目</summary>
        public void SelectStep(int stepIndex)
        {
            if (!_open) return;
            if (_answer.Contains(stepIndex)) return;                 // 已选过
            if (_answer.Count >= data.steps.Count) return;           // 槽位满了

            _answer.Add(stepIndex);
            RefreshUI();
            PlayClick();

            if (_answer.Count == data.steps.Count) Submit();
        }

        /// <summary>点击已填入的槽位 → 撤销该位置及之后的选择</summary>
        public void RemoveAt(int slotIndex)
        {
            if (!_open || slotIndex < 0 || slotIndex >= _answer.Count) return;
            _answer.RemoveRange(slotIndex, _answer.Count - slotIndex);
            RefreshUI();
            PlayClick();
        }

        /// <summary>“提交”按钮（也可自动触发）</summary>
        public void Submit()
        {
            if (!_open) return;
            if (_answer.Count != data.steps.Count)
            {
                if (feedbackText != null) feedbackText.text = "还有步骤没排进去";
                return;
            }

            bool correct = _answer.Select((v, i) => v == i).All(x => x);

            if (correct)
            {
                _timer.Stop();
                _open = false;
                if (feedbackText != null) feedbackText.text = data.passMessage;
                ShowTips();
                PlayClick();
                onPassed.Invoke();
                Invoke(nameof(ClosePanelDelayed), 1.2f);
            }
            else
            {
                _wrongCount++;
                if (feedbackText != null) feedbackText.text = data.wrongMessage;
                FlashWrong();

                if (failOnWrongAnswer || (maxWrongAttempts > 0 && _wrongCount >= maxWrongAttempts))
                    Fail(data.wrongMessage);
                else
                {
                    // 保留选择，让用户继续调整；时间继续走
                    _answer.Clear();
                    RefreshUI();
                }
            }
        }

        void Fail(string reason)
        {
            if (!_open) return;
            _open = false;
            _timer.Stop();
            onFailed.Invoke(reason);
        }

        void ClosePanelDelayed()
        {
            if (panel != null) panel.SetActive(false);
        }

        // ------------------------------------------------------------ UI 刷新

        void RefreshUI()
        {
            for (int i = 0; i < _slots.Count; i++)
            {
                bool filled = i < _answer.Count;
                string txt = filled
                    ? $"{i + 1}. {data.steps[_answer[i]].text}"
                    : $"{i + 1}. ________";
                _slots[i].SetContent(txt, filled);
            }

            foreach (var item in _items)
                item.SetSelected(_answer.Contains(item.StepIndex));

            if (progressText != null)
                progressText.text = $"已排 {_answer.Count}/{data.steps.Count} 步";
        }

        void ShowTips()
        {
            if (feedbackText == null || data == null) return;
            foreach (var s in data.steps)
                feedbackText.text += "\n· " + s.tip;
        }

        void FlashWrong()
        {
            foreach (var s in _slots) s.FlashError();
        }

        void HandleTick(float remain)
        {
            if (timerText == null) return;
            timerText.text = $"剩余 {remain:F1} 秒";
            timerText.color = remain <= 10f ? Color.red : Color.white;
        }

        void PlayClick() => AudioManager.Instance?.PlayUiClick();

        // ------------------------------------------------------------ 调试用

        /// <summary>键盘/测试直接按正确顺序作答</summary>
        public void DebugAutoSolve()
        {
            if (!_open) return;
            _answer.Clear();
            for (int i = 0; i < data.steps.Count; i++) _answer.Add(i);
            RefreshUI();
            Submit();
        }
    }
}
