using System.Collections.Generic;
using UnityEngine;

namespace VRFireDrill
{
    [System.Serializable]
    public class StepEntry
    {
        [Tooltip("内部标识，随便填，保持唯一即可")]
        public string key;
        [TextArea(2, 4)]
        [Tooltip("显示给用户的步骤文案")]
        public string text;
        [Tooltip("排序正确时的补充说明，答完后逐条展示")]
        public string tip;
    }

    /// <summary>
    /// 消防安全步骤题库（Project 右键 Create → VR Fire Drill → Fire Safety Quiz）
    /// steps 列表的顺序 = 正确顺序。默认内容取自你给的 6 条步骤。
    /// </summary>
    [CreateAssetMenu(fileName = "FireSafetyQuiz", menuName = "VR Fire Drill/Fire Safety Quiz")]
    public class QuizData : ScriptableObject
    {
        [Header("题目")]
        [TextArea(2, 4)]
        public string question = "办公室消防知识练习：灭火器灭火分为几步骤？请按正确顺序排列。";

        [Header("步骤（列表顺序即正确答案）")]
        public List<StepEntry> steps = new List<StepEntry>();

        [Header("结果文案")]
        public string passMessage = "排序正确！现在可以拿起灭火器灭火了。";
        public string wrongMessage = "顺序不对，再想想！";
        public string timeoutMessage = "排序超时，练习失败。";

        void OnValidate()
        {
            if (steps == null || steps.Count == 0) ResetToDefault();
        }

        [ContextMenu("恢复默认 6 步")]
        public void ResetToDefault()
        {
            steps = new List<StepEntry>
            {
                new StepEntry {
                    key = "alarm",
                    text = "身处火场，警报响起：保持冷静，大声呼救并拨打 119 报警",
                    tip = "先报警再自救，火势失控时优先撤离。"
                },
                new StepEntry {
                    key = "locate",
                    text = "确认起火位置与火势，判断是否能够自行扑灭",
                    tip = "只在初期小火、逃生通道畅通时才尝试灭火。"
                },
                new StepEntry {
                    key = "fetch",
                    text = "移动到灭火器放置点，取下灭火器",
                    tip = "办公室灭火器通常在走廊、门口、楼梯间等显眼位置。"
                },
                new StepEntry {
                    key = "distance",
                    text = "站到上风方向，远离着火点，与火源保持 2–3 米安全距离",
                    tip = "上风位可避免被浓烟和火焰反扑。"
                },
                new StepEntry {
                    key = "pin",
                    text = "拔出保险销，握住喷管，对准火焰根部",
                    tip = "对准「根部」而不是火苗顶部，这是灭火成败的关键。"
                },
                new StepEntry {
                    key = "sweep",
                    text = "压下压把左右扫射，确认火焰完全熄灭不再复燃",
                    tip = "扑灭后继续观察，防止复燃。"
                }
            };
        }
    }
}
