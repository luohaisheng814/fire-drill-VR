using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace VRFireDrill
{
    /// <summary>
    /// 排序题里的一条步骤（左侧候选区）。挂在一个带 Button 的 World Space UI 物体上。
    /// 手柄射线点击 → 触发 Button.onClick → Select()。
    /// </summary>
    public class QuizStepItem : MonoBehaviour
    {
        [Header("UI")]
        public TextMeshProUGUI label;
        public Button button;
        public Image background;

        [Header("颜色")]
        public Color normalColor = new Color(0.13f, 0.15f, 0.18f, 0.95f);
        public Color selectedColor = new Color(0.10f, 0.45f, 0.28f, 0.95f);

        public int StepIndex { get; private set; }
        QuizManager _manager;

        public void Setup(int stepIndex, string text, QuizManager manager)
        {
            StepIndex = stepIndex;
            _manager = manager;
            if (label != null) label.text = text;

            if (button == null) button = GetComponent<Button>();
            if (button != null)
            {
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(Select);
            }
            SetSelected(false);
        }

        /// <summary>Button OnClick 直接绑这个方法</summary>
        public void Select() => _manager?.SelectStep(StepIndex);

        public void SetSelected(bool on)
        {
            if (background != null) background.color = on ? selectedColor : normalColor;
            if (button != null) button.interactable = !on;   // 已选中的不可再点
        }
    }
}
