using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

namespace VRFireDrill
{
    public enum ExtinguisherStage
    {
        PinLocked,   // 第 0 步：保险销还在（未解锁 / 未答题）
        PinRemoved,  // 第 1 步完成：保险销已拔
        NozzleOut,   // 第 2 步完成：单击转换形态，灭火口出现
        Spraying     // 第 3 步：对准火焰根部喷射中
    }

    /// <summary>
    /// 灭火器三步流程控制器。
    ///   第 1 步：打开保险（抓住保险销拉出，或按一次扳机拔出）
    ///   第 2 步：单击扳机 → 转换形态，灭火口/喷管出现
    ///   第 3 步：灭火口对准火焰根部 → 按下扳机 → 喷出粒子喷雾
    /// 只有 Locked=false（排序题通过）时才允许推进步骤。
    /// </summary>
    public class ExtinguisherController : MonoBehaviour
    {
        [Header("部件引用")]
        public SafetyPin safetyPin;
        [Tooltip("灭火口/喷管整体，初始为隐藏（收起状态）")]
        public GameObject nozzleGroup;
        [Tooltip("喷管动画机（可选，有就触发 Deploy / Retract）")]
        public Animator hoseAnimator;
        public SprayEmitter spray;
        public Transform nozzleTip;

        [Header("输入")]
        [Tooltip("推进步骤的按键：XRI RightHand/LeftHand 的 Activate（扳机）")]
        public InputActionReference advanceAction;
        [Tooltip("true = 按住扳机持续喷射；false = 点一下开、再点一下关")]
        public bool holdToSpray = true;

        [Header("规则")]
        [Tooltip("允许用按键代替"手拔保险销"（新手友好，建议 true）")]
        public bool allowButtonToPullPin = true;
        [Tooltip("喷射必须由"对准根部"才生效（由 SprayEmitter 判定）")]
        public bool requireRootAim = true;

        [Header("音效")]
        public AudioSource pinAudio;
        public AudioSource morphAudio;

        [Header("事件")]
        public UnityEvent<ExtinguisherStage> onStageChanged = new UnityEvent<ExtinguisherStage>();
        public UnityEvent<string> onHint = new UnityEvent<string>();
        public UnityEvent onPickedUp = new UnityEvent();

        public ExtinguisherStage Stage { get; private set; } = ExtinguisherStage.PinLocked;
        public bool IsGrabbed { get; private set; }
        public bool Locked { get; private set; } = true;

        bool _sprayPressed;
        System.Action<UnityEngine.InputSystem.InputAction.CallbackContext> _onAdvance;
        System.Action<UnityEngine.InputSystem.InputAction.CallbackContext> _onRelease;

        // ------------------------------------------------------------ 生命周期

        void OnEnable()
        {
            if (advanceAction == null || advanceAction.action == null) return;
            _onAdvance = _ => { if (IsGrabbed) OnAdvancePressed(); };
            _onRelease = _ => { if (IsGrabbed) OnAdvanceReleased(); };
            advanceAction.action.Enable();
            advanceAction.action.performed += _onAdvance;
            advanceAction.action.canceled += _onRelease;
        }

        void OnDisable()
        {
            if (advanceAction == null || advanceAction.action == null) return;
            advanceAction.action.performed -= _onAdvance;
            advanceAction.action.canceled -= _onRelease;
            _onAdvance = null;
            _onRelease = null;
        }

        void Start()
        {
            if (safetyPin != null) safetyPin.onPinRemoved.AddListener(OnPinRemoved);
            if (spray != null)
            {
                spray.holdToSpray = holdToSpray;
                spray.onAimValidChanged.AddListener(valid =>
                {
                    if (Stage == ExtinguisherStage.Spraying && !valid && requireRootAim)
                        Hint("没对准！请把灭火口对准火焰根部");
                });
            }
            if (nozzleGroup != null) nozzleGroup.SetActive(false);
            SetStage(ExtinguisherStage.PinLocked);
        }

        // ------------------------------------------------------------ 外部调用

        public void SetGrabbed(bool grabbed)
        {
            IsGrabbed = grabbed;
            if (grabbed) onPickedUp.Invoke();
            else ForceStopSpray();
        }

        /// <summary>排序题未通过时锁住，不允许拔销/展开/喷射</summary>
        public void LockAll() => Locked = true;
        public void UnlockAll() => Locked = false;

        /// <summary>扳机按下（单次点击）</summary>
        public void OnAdvancePressed()
        {
            if (Locked)
            {
                Hint("请先完成消防安全步骤排序");
                return;
            }
            if (!IsGrabbed) return;

            switch (Stage)
            {
                case ExtinguisherStage.PinLocked:
                    if (allowButtonToPullPin && safetyPin != null) safetyPin.RemoveByButton();
                    else Hint("第 1 步：抓住保险销并拉出");
                    break;

                case ExtinguisherStage.PinRemoved:
                    DeployNozzle();
                    break;

                case ExtinguisherStage.NozzleOut:
                    _sprayPressed = true;
                    StartSpray();
                    break;

                case ExtinguisherStage.Spraying:
                    if (!holdToSpray) StopSpray();
                    break;
            }
        }

        /// <summary>扳机松开</summary>
        public void OnAdvanceReleased()
        {
            _sprayPressed = false;
            if (Stage == ExtinguisherStage.Spraying && holdToSpray) StopSpray();
        }

        public void ForceStopSpray()
        {
            if (Stage == ExtinguisherStage.Spraying) StopSpray();
        }

        // ------------------------------------------------------------ 步骤实现

        void OnPinRemoved()
        {
            if (Stage != ExtinguisherStage.PinLocked) return;
            pinAudio?.Play();
            SetStage(ExtinguisherStage.PinRemoved);
            Hint("第 2 步：单击扳机，展开灭火口");
        }

        void DeployNozzle()
        {
            if (nozzleGroup != null) nozzleGroup.SetActive(true);
            if (hoseAnimator != null) hoseAnimator.SetTrigger("Deploy");
            morphAudio?.Play();

            if (spray != null && nozzleTip != null) spray.nozzleTip = nozzleTip;

            SetStage(ExtinguisherStage.NozzleOut);
            Hint("第 3 步：灭火口对准火焰根部，按下扳机喷射");
        }

        void StartSpray()
        {
            if (spray == null) return;

            if (requireRootAim && !spray.CheckAim(out _))
            {
                Hint("没对准火焰根部！把灭火口压低，对准火焰底部");
                if (!holdToSpray) return;
            }

            spray.StartSpray();
            SetStage(ExtinguisherStage.Spraying);
        }

        void StopSpray()
        {
            spray?.StopSpray();
            SetStage(ExtinguisherStage.NozzleOut);
        }

        void SetStage(ExtinguisherStage next)
        {
            Stage = next;
            onStageChanged.Invoke(next);
        }

        void Hint(string msg) => onHint.Invoke(msg);

        /// <summary>重开时复位</summary>
        public void ResetToStart()
        {
            ForceStopSpray();
            safetyPin?.Reset();
            if (nozzleGroup != null) nozzleGroup.SetActive(false);
            if (hoseAnimator != null) hoseAnimator.SetTrigger("Retract");
            SetStage(ExtinguisherStage.PinLocked);
        }
    }
}
