using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit;

namespace VRFireDrill
{
    /// <summary>
    /// 灭火器的"被拾取"功能。
    /// 规则：手柄点击（Grip 抓取）后灭火器直接被手柄控制；
    ///       松开抓取键不会掉落（粘手），必须【双击放下键】才会放下。
    ///
    /// 用法：替换掉物体上的 XR Grab Interactable，或者在 Add Component 里直接加本脚本（会自动带抓取能力）。
    /// XRI 3.x 需要额外 using UnityEngine.XR.Interaction.Toolkit.Interactables;
    /// </summary>
    [SelectionBase]
    [DisallowMultipleComponent]
    public class ExtinguisherGrab : XRGrabInteractable
    {
        [Header("放下设置")]
        [Tooltip("双击这个键才放下灭火器（建议绑 A / X 键，不要和抓取键 Grip 同一个）")]
        public InputActionReference dropAction;
        public float doubleClickWindow = 0.4f;

        [Tooltip("true = 松手不掉，必须双击才掉；false = 恢复成普通 XRI 抓取行为")]
        public bool stickyGrab = true;

        [Header("引用")]
        public ExtinguisherController controller;

        public UnityEngine.Events.UnityEvent onPickedUp = new UnityEngine.Events.UnityEvent();
        public UnityEngine.Events.UnityEvent onDropped = new UnityEngine.Events.UnityEvent();

        int _clickCount;
        float _lastClickTime;
        bool _forceDrop;
        bool _reattaching;
        IXRSelectInteractor _interactor;

        public bool IsHeld => _interactor != null;

        // ------------------------------------------------------------ XRI 回调

        protected override void OnSelectEntered(SelectEnterEventArgs args)
        {
            base.OnSelectEntered(args);
            _interactor = args.interactorObject;
            _clickCount = 0;
            _forceDrop = false;

            controller?.SetGrabbed(true);
            onPickedUp.Invoke();
        }

        protected override void OnSelectExited(SelectExitEventArgs args)
        {
            base.OnSelectExited(args);

            bool reallyDrop = _forceDrop || !stickyGrab;
            _forceDrop = false;

            if (reallyDrop)
            {
                controller?.SetGrabbed(false);
                controller?.ForceStopSpray();
                onDropped.Invoke();
                _interactor = null;
                return;
            }

            // 松手不掉：下一帧重新吸附回手上
            if (!_reattaching && _interactor != null && isActiveAndEnabled)
                StartCoroutine(Reattach());
        }

        IEnumerator Reattach()
        {
            _reattaching = true;
            yield return null;
            _reattaching = false;

            if (_interactor == null || _forceDrop || !isActiveAndEnabled) yield break;
            if (interactionManager != null)
                interactionManager.SelectEnter(_interactor, this);
        }

        // ------------------------------------------------------------ 双击放下

        void OnEnable()
        {
            if (dropAction != null && dropAction.action != null)
            {
                dropAction.action.Enable();
                dropAction.action.performed += OnDropPerformed;
            }
        }

        void OnDisable()
        {
            if (dropAction != null && dropAction.action != null)
                dropAction.action.performed -= OnDropPerformed;
        }

        void OnDropPerformed(InputAction.CallbackContext ctx)
        {
            if (!stickyGrab || _interactor == null) return;

            float now = Time.unscaledTime;
            _clickCount = (now - _lastClickTime <= doubleClickWindow) ? _clickCount + 1 : 1;
            _lastClickTime = now;

            if (_clickCount >= 2)
            {
                _clickCount = 0;
                ForceDrop();
            }
        }

        /// <summary>强制放下（也可被 UI 按钮 / 失败流程调用）</summary>
        public void ForceDrop()
        {
            if (_interactor == null) return;
            _forceDrop = true;
            if (interactionManager != null)
                interactionManager.SelectExit(_interactor, this);
        }
    }
}
