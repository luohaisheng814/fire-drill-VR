using UnityEngine;
using UnityEngine.Events;

namespace VRFireDrill
{
    /// <summary>
    /// 灭火口喷雾：粒子效果 + 命中判定。
    /// 判定逻辑：从灭火口沿 Z+（蓝轴）方向做射线，
    ///   1) 距离在 min~max 之间
    ///   2) 与"灭火口 → 火焰根部"的夹角小于 rootAimAngle
    ///   3) 中间没有遮挡
    /// 同时满足才算"对准根部"，按满额 DPS 掉血；否则只有 offRootDamageFactor 的微弱效果。
    /// </summary>
    public class SprayEmitter : MonoBehaviour
    {
        [Header("喷射口")]
        [Tooltip("灭火口尖端的空物体，其蓝轴(Z+) 必须指向喷射方向")]
        public Transform nozzleTip;
        public ParticleSystem sprayParticles;
        public ParticleSystem impactParticles;

        [Header("目标")]
        public FireTarget target;

        [Header("参数")]
        public float maxRange = 3.5f;
        public float minRange = 0.3f;
        public float rootAimAngle = 25f;
        public float rootDamagePerSecond = 45f;
        [Range(0f, 1f)] public float offRootDamageFactor = 0.15f;
        [Tooltip("射线半径，稍微放宽命中，手感更好")]
        public float aimRayRadius = 0.12f;
        public LayerMask blockingLayers = ~0;

        [Header("模式")]
        [Tooltip("true = 按住喷射、松手停；false = 点一下开始、再点一下停")]
        public bool holdToSpray = true;

        [Header("事件")]
        public UnityEvent<bool> onAimValidChanged = new UnityEvent<bool>();
        public UnityEvent onSprayStarted = new UnityEvent();
        public UnityEvent onSprayStopped = new UnityEvent();

        public bool Spraying { get; private set; }
        public bool AimValid { get; private set; }

        bool _lastAimValid;
        public AudioSource sprayAudio;

        void Start()
        {
            SetSprayVisual(false);
        }

        void Update()
        {
            if (target == null || nozzleTip == null) return;

            bool alive = target.IsAlive;
            bool valid = Spraying && alive && CheckAim(out _);
            AimValid = valid;

            if (valid != _lastAimValid)
            {
                _lastAimValid = valid;
                onAimValidChanged.Invoke(valid);
            }

            if (!Spraying || !alive) return;

            float dps = valid ? rootDamagePerSecond : rootDamagePerSecond * offRootDamageFactor;
            target.ApplyExtinguish(dps * Time.deltaTime);

            if (impactParticles != null)
            {
                // 命中特效落在实际命中点上
                if (CheckAim(out Vector3 hitPoint))
                {
                    impactParticles.transform.position = hitPoint;
                    if (!impactParticles.isPlaying) impactParticles.Play();
                }
                else impactParticles.Stop(false, ParticleSystemStopBehavior.StopEmitting);
            }
        }

        public void StartSpray()
        {
            if (Spraying) return;
            Spraying = true;
            SetSprayVisual(true);
            if (sprayAudio != null && !sprayAudio.isPlaying) sprayAudio.Play();
            onSprayStarted.Invoke();
        }

        public void StopSpray()
        {
            if (!Spraying) return;
            Spraying = false;
            SetSprayVisual(false);
            if (sprayAudio != null) sprayAudio.Stop();
            impactParticles?.Stop(false, ParticleSystemStopBehavior.StopEmitting);
            onSprayStopped.Invoke();
        }

        void SetSprayVisual(bool on)
        {
            if (sprayParticles == null) return;
            if (on) sprayParticles.Play();
            else sprayParticles.Stop(false, ParticleSystemStopBehavior.StopEmitting);
        }

        /// <summary>是否瞄准火焰根部；hitPoint 为命中点</summary>
        public bool CheckAim(out Vector3 hitPoint)
        {
            hitPoint = Vector3.zero;
            if (target == null || nozzleTip == null) return false;

            Vector3 origin = nozzleTip.position;
            Vector3 dir = nozzleTip.forward;               // 蓝轴 Z+
            Vector3 toRoot = target.RootPosition - origin;
            float dist = toRoot.magnitude;

            if (dist < minRange || dist > maxRange) return false;
            float angle = Vector3.Angle(dir, toRoot.normalized);
            if (angle > rootAimAngle) return false;

            // 遮挡检测：喷雾到根部之间不能有墙/桌子
            if (Physics.SphereCast(origin, aimRayRadius, toRoot.normalized, out RaycastHit hit, dist, blockingLayers))
            {
                if (hit.collider.GetComponentInParent<FireTarget>() == null) return false;
            }

            hitPoint = target.RootPosition;
            return true;
        }

        /// <summary>true 表示喷射方向大致对着火（不严格要求根部），用于 UI 提示</summary>
        public bool IsPointingAtFire(float toleranceDeg = 60f)
        {
            if (target == null || nozzleTip == null) return false;
            Vector3 toFire = target.transform.position - nozzleTip.position;
            return Vector3.Angle(nozzleTip.forward, toFire.normalized) <= toleranceDeg;
        }
    }
}
