using UnityEngine;
using UnityEngine.Events;
using UnityEngine.XR.Interaction.Toolkit;

namespace VRFireDrill
{
    /// <summary>
    /// 灭火器保险销：两种拔法
    ///   1) 用另一只手抓住它往外拉，离开原位超过 pullDistance 自动脱落（沉浸感最好）
    ///   2) 代码调用 RemoveByButton()（按扳机拔出）
    /// 保险销自己挂一个 XR Grab Interactable（不要加 ExtinguisherGrab，让它松手即掉）。
    /// </summary>
    public class SafetyPin : MonoBehaviour
    {
        [Header("判定")]
        [Tooltip("保险销原来的位置（复制一个空物体放在销子初始位置即可）")]
        public Transform homePoint;
        public float pullDistance = 0.12f;
        [Tooltip("拔出后是否隐藏销子")] [SerializeField] bool hideOnRemoved = true;

        [Header("事件")]
        public UnityEvent onPinRemoved = new UnityEvent();

        public bool Removed { get; private set; }

        Vector3 _homeLocalPos;
        Transform _homeParent;
        XRGrabInteractable _grab;

        void Awake()
        {
            _grab = GetComponent<XRGrabInteractable>();
            CacheHome();
        }

        void CacheHome()
        {
            if (homePoint != null)
            {
                _homeLocalPos = homePoint.localPosition;
                _homeParent = homePoint.parent;
            }
            else
            {
                _homeLocalPos = transform.localPosition;
                _homeParent = transform.parent;
            }
        }

        void Update()
        {
            if (Removed || _grab == null) return;
            if (!_grab.isSelected) return;   // 只有被抓住时才判定"拉出"

            float d = Vector3.Distance(transform.position, GetHomeWorldPos());
            if (d >= pullDistance) Remove();
        }

        Vector3 GetHomeWorldPos()
        {
            if (homePoint != null) return homePoint.position;
            return _homeParent != null ? _homeParent.TransformPoint(_homeLocalPos) : _homeLocalPos;
        }

        /// <summary>按键方式拔出（ExtinguisherController 调用）</summary>
        public void RemoveByButton()
        {
            if (Removed) return;
            Remove();
        }

        void Remove()
        {
            if (Removed) return;
            Removed = true;

            if (_grab != null)
            {
                // 先从手上脱离，避免残留选中状态
                if (_grab.isSelected && _grab.interactionManager != null && _grab.interactorsSelecting.Count > 0)
                    _grab.interactionManager.SelectExit(_grab.interactorsSelecting[0], _grab);
                _grab.enabled = false;
            }

            if (hideOnRemoved) gameObject.SetActive(false);
            onPinRemoved.Invoke();
        }

        public void Reset()
        {
            Removed = false;
            gameObject.SetActive(true);
            if (_grab != null) _grab.enabled = true;
            transform.localPosition = _homeLocalPos;
            transform.localRotation = Quaternion.identity;
            var rb = GetComponent<Rigidbody>();
            if (rb != null) { rb.isKinematic = false; rb.velocity = Vector3.zero; rb.angularVelocity = Vector3.zero; }
        }
    }
}
