#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace VRFireDrill.EditorTools
{
    /// <summary>
    /// 编辑器一键搭建工具：菜单栏 VR Fire Drill → ...
    /// 用来在你下载好办公室模型和灭火器模型之前，先搭一套能跑通的占位场景。
    /// 正式模型下载好后，只需替换 Mesh / 粒子，不需要改脚本。
    /// </summary>
    public static class FireDrillSetupWizard
    {
        const string RootName = "FireDrill";

        [MenuItem("VR Fire Drill/1. 创建占位办公室（地板+墙+桌子）")]
        public static void CreateOffice()
        {
            var root = GetOrCreateRoot();

            var room = new GameObject("Office_Room");
            room.transform.SetParent(root.transform);

            // 地板
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "Floor";
            floor.transform.SetParent(room.transform);
            floor.transform.localScale = new Vector3(10f, 0.1f, 8f);
            floor.transform.localPosition = new Vector3(0f, -0.05f, 0f);

            // 天花板
            var ceil = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ceil.name = "Ceiling";
            ceil.transform.SetParent(room.transform);
            ceil.transform.localScale = new Vector3(10f, 0.1f, 8f);
            ceil.transform.localPosition = new Vector3(0f, 3f, 0f);

            // 四面墙
            CreateWall(room.transform, "Wall_Front", new Vector3(10f, 3f, 0.1f), new Vector3(0f, 1.5f, 4f));
            CreateWall(room.transform, "Wall_Back", new Vector3(10f, 3f, 0.1f), new Vector3(0f, 1.5f, -4f));
            CreateWall(room.transform, "Wall_Left", new Vector3(0.1f, 3f, 8f), new Vector3(-5f, 1.5f, 0f));
            CreateWall(room.transform, "Wall_Right", new Vector3(0.1f, 3f, 8f), new Vector3(5f, 1.5f, 0f));

            // 办公桌 + 纸箱（着火点旁的遮挡物）
            var desk = GameObject.CreatePrimitive(PrimitiveType.Cube);
            desk.name = "Desk";
            desk.transform.SetParent(room.transform);
            desk.transform.localScale = new Vector3(1.6f, 0.08f, 0.8f);
            desk.transform.localPosition = new Vector3(-1.2f, 0.75f, 1.6f);

            Selection.activeGameObject = room;
            Debug.Log("[FireDrill] 占位办公室已创建；正式模型下载后替换这些 Mesh 即可。");
        }

        static void CreateWall(Transform parent, string name, Vector3 scale, Vector3 pos)
        {
            var w = GameObject.CreatePrimitive(PrimitiveType.Cube);
            w.name = name;
            w.transform.SetParent(parent);
            w.transform.localScale = scale;
            w.transform.localPosition = pos;
        }

        [MenuItem("VR Fire Drill/2. 创建火焰点（含生命值）")]
        public static void CreateFire()
        {
            var root = GetOrCreateRoot();

            var fire = new GameObject("Fire_Point");
            fire.transform.SetParent(root.transform);
            fire.transform.localPosition = new Vector3(1.6f, 0f, 1.2f);   // 放在玩家一侧

            var rootPoint = new GameObject("RootPoint");
            rootPoint.transform.SetParent(fire.transform);
            rootPoint.transform.localPosition = new Vector3(0f, 0.15f, 0f);

            // 火焰粒子（用默认材质先占位，之后换成火焰贴图）
            var psGo = new GameObject("Fire_Particles");
            psGo.transform.SetParent(fire.transform);
            psGo.transform.localPosition = new Vector3(0f, 0.4f, 0f);
            var ps = psGo.AddComponent<ParticleSystem>();
            SetParticleShape(ps, 0.35f);

            var light = new GameObject("Fire_Light");
            light.transform.SetParent(fire.transform);
            light.transform.localPosition = new Vector3(0f, 0.6f, 0f);
            var l = light.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = new Color(1f, 0.55f, 0.15f);
            l.intensity = 2f;
            l.range = 6f;

            var target = fire.AddComponent<FireTarget>();
            target.rootPoint = rootPoint.transform;
            target.fireParticles = ps;
            target.fireLight = l;
            target.maxHP = 100f;
            target.currentHP = 100f;

            Selection.activeGameObject = fire;
            Debug.Log("[FireDrill] 火焰点已创建，把 Fire_Point 拖到 GameManager.fire。");
        }

        static void SetParticleShape(ParticleSystem ps, float radius)
        {
            var main = ps.main;
            main.startLifetime = 1.2f;
            main.startSpeed = 1.5f;
            main.startSize = 0.35f;
            main.maxParticles = 400;
            main.simulationSpace = ParticleSystemSimulationSpace.World;

            var emission = ps.emission;
            emission.rateOverTime = 60f;

            var shape = ps.shape;
            shape.shapeType = ParticleSystemShapeType.Cone;
            shape.radius = radius;
            shape.angle = 12f;
        }

        [MenuItem("VR Fire Drill/3. 把选中物体做成灭火器（含三步流程）")]
        public static void CreateExtinguisher()
        {
            var selected = Selection.activeGameObject;
            if (selected == null)
            {
                Debug.LogWarning("[FireDrill] 先选中灭火器的模型根节点再执行。");
                return;
            }

            var root = GetOrCreateRoot();
            selected.transform.SetParent(root.transform);

            // 保险销
            var pin = new GameObject("SafetyPin");
            pin.transform.SetParent(selected.transform);
            pin.transform.localPosition = new Vector3(0f, 0.32f, 0.08f);
            var pinMesh = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pinMesh.transform.SetParent(pin.transform);
            pinMesh.transform.localScale = new Vector3(0.012f, 0.06f, 0.012f);
            var pinRb = pin.AddComponent<Rigidbody>();
            pinRb.mass = 0.05f;
            var pinSafety = pin.AddComponent<SafetyPin>();
            pinSafety.homePoint = pin.transform;

            // 灭火口（初始隐藏）
            var nozzle = new GameObject("NozzleGroup");
            nozzle.transform.SetParent(selected.transform);
            nozzle.transform.localPosition = new Vector3(0f, 0.3f, 0.14f);
            nozzle.SetActive(false);

            var tip = new GameObject("NozzleTip");
            tip.transform.SetParent(nozzle.transform);
            tip.transform.localPosition = new Vector3(0f, 0f, 0.18f);   // Z+ 为喷射方向

            // 喷雾粒子
            var sprayGo = new GameObject("Spray_Particles");
            sprayGo.transform.SetParent(nozzle.transform);
            sprayGo.transform.localPosition = Vector3.zero;
            var sprayPs = sprayGo.AddComponent<ParticleSystem>();
            var sm = sprayPs.main;
            sm.startLifetime = 0.6f;
            sm.startSpeed = 9f;
            sm.startSize = 0.06f;
            sm.maxParticles = 800;
            sm.simulationSpace = ParticleSystemSimulationSpace.World;
            var se = sprayPs.emission;
            se.rateOverTime = 300f;
            var ss = sprayPs.shape;
            ss.shapeType = ParticleSystemShapeType.Cone;
            ss.angle = 9f;
            ss.radius = 0.02f;

            var emitter = selected.AddComponent<SprayEmitter>();
            emitter.sprayParticles = sprayPs;
            emitter.nozzleTip = tip.transform;

            var ctrl = selected.AddComponent<ExtinguisherController>();
            ctrl.safetyPin = pinSafety;
            ctrl.nozzleGroup = nozzle;
            ctrl.nozzleTip = tip.transform;
            ctrl.spray = emitter;

            // 抓取（粘手 + 双击放下）
            var grab = selected.AddComponent<ExtinguisherGrab>();
            grab.controller = ctrl;
            var rb = selected.GetComponent<Rigidbody>();
            if (rb == null) rb = selected.gameObject.AddComponent<Rigidbody>();
            rb.mass = 3f;
            if (selected.GetComponent<Collider>() == null)
                selected.gameObject.AddComponent<BoxCollider>();

            Selection.activeGameObject = selected;
            Debug.Log("[FireDrill] 灭火器已装配。记得：ExtinguisherGrab.dropAction 绑 A/X 键，" +
                      "ExtinguisherController.advanceAction 绑扳机 Activate。");
        }

        [MenuItem("VR Fire Drill/4. 创建总控与配置")]
        public static void CreateManagers()
        {
            var root = GetOrCreateRoot();

            var gmGo = new GameObject("GameManager");
            gmGo.transform.SetParent(root.transform);
            var gm = gmGo.AddComponent<GameManager>();
            var cfg = gmGo.AddComponent<DebugKeyboardFallback>();

            var uiGo = new GameObject("UIManager");
            uiGo.transform.SetParent(root.transform);
            uiGo.AddComponent<UIManager>();

            var audioGo = new GameObject("AudioManager");
            audioGo.transform.SetParent(root.transform);
            audioGo.AddComponent<AudioManager>();

            var quizGo = new GameObject("QuizManager");
            quizGo.transform.SetParent(root.transform);
            quizGo.AddComponent<QuizManager>();

            cfg.config = gm.config;

            Selection.activeGameObject = gmGo;
            Debug.Log("[FireDrill] 总控已创建，请在 Inspector 里补上引用与 Config 资源。");
        }

        static GameObject GetOrCreateRoot()
        {
            var root = GameObject.Find(RootName);
            if (root == null) root = new GameObject(RootName);
            return root;
        }
    }
}
#endif
