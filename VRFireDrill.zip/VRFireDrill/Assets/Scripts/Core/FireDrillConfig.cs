using UnityEngine;

namespace VRFireDrill
{
    /// <summary>
    /// 全局可调参数（在 Project 窗口右键 Create → VR Fire Drill → Config 生成一份，拖到 GameManager 上）
    /// 所有时间、血量、伤害、判定角度都在这里改，不用改代码。
    /// </summary>
    [CreateAssetMenu(fileName = "FireDrillConfig", menuName = "VR Fire Drill/Config")]
    public class FireDrillConfig : ScriptableObject
    {
        [Header("时间限制（秒）")]
        [Tooltip("整个情景练习的总时长，超时即失败")]
        public float totalDrillSeconds = 120f;

        [Tooltip("消防安全步骤排序题的限时，超时即失败")]
        public float quizSeconds = 30f;

        [Tooltip("开场（办公室消防知识练习）停留时长，0 = 必须手动点“开始”")]
        public float introSeconds = 0f;

        [Header("火焰")]
        public float fireMaxHP = 100f;
        [Tooltip("对准火焰根部时每秒削减的生命值")]
        public float rootDamagePerSecond = 45f;
        [Tooltip("没对准根部时的伤害系数（0.15 = 只有 15% 效果）")]
        [Range(0f, 1f)] public float offRootDamageFactor = 0.15f;
        [Tooltip("判定“对准根部”的最大夹角（度）")]
        [Range(5f, 90f)] public float rootAimAngle = 25f;
        [Tooltip("有效喷射距离（米）")]
        public float maxSprayRange = 3.5f;
        [Tooltip("火焰自动复燃速度，0 = 不复燃")]
        public float regrowPerSecond = 0f;

        [Header("交互")]
        [Tooltip("双击放下灭火器的判定窗口（秒）")]
        public float doubleClickWindow = 0.4f;
        [Tooltip("灭火口（喷管）可以放在离火焰多近才判定有效")]
        public float minSprayRange = 0.3f;

        [Header("调试")]
        [Tooltip("无头显时用键盘模拟手柄操作，方便在 PC 上测试逻辑")]
        public bool keyboardFallback = true;

        [Header("提示文案")]
        public string hintPickExtinguisher = "请拿起灭火器";
        public string hintPullPin = "第 1 步：拔掉保险销";
        public string hintDeployNozzle = "第 2 步：单击扳机，展开灭火口";
        public string hintSpray = "第 3 步：灭火口对准火焰根部，按下扳机喷射";
        public string hintAimRoot = "没对准！请把灭火口对准火焰根部";
        public string hintQuiz = "先完成消防安全步骤排序";
    }
}
