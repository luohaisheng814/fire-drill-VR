using System;

namespace VRFireDrill
{
    /// <summary>
    /// 纯逻辑倒计时器：总计时（2 分钟）和排序题计时（30 秒）都用它。
    /// </summary>
    public class CountdownTimer
    {
        public float Duration { get; private set; }
        public float Remaining { get; private set; }
        public bool Running { get; private set; }
        public bool Finished { get; private set; }

        public event Action<float> onTick;      // 每帧回调，参数为剩余秒数
        public event Action onFinished;         // 归零时回调一次

        public void Start(float duration)
        {
            Duration = duration;
            Remaining = duration;
            Running = true;
            Finished = false;
        }

        public void Pause() => Running = false;
        public void Resume() => Running = !Finished;

        public void Stop()
        {
            Running = false;
            Finished = false;
            Remaining = 0f;
        }

        /// <summary>每帧调用，dt 为 Time.deltaTime</summary>
        public void Tick(float dt)
        {
            if (!Running || Finished) return;

            Remaining -= dt;
            if (Remaining <= 0f)
            {
                Remaining = 0f;
                Finished = true;
                Running = false;
                onTick?.Invoke(0f);
                onFinished?.Invoke();
                return;
            }
            onTick?.Invoke(Remaining);
        }

        public void AddTime(float seconds)
        {
            Remaining = Math.Max(0f, Remaining + seconds);
            if (Remaining > 0f) Finished = false;
        }
    }
}
