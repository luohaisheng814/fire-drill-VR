using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace VRFireDrill
{
    public enum DrillState
    {
        Idle,           // 未开始（开场页）
        Intro,          // 开场：办公室消防知识练习
        Extinguishing,  // 灭火阶段（可被排序题打断）
        Quiz,           // 消防安全步骤排序题
        Success,        // 通关
        Failed          // 失败
    }

    /// <summary>
    /// 总控：状态机 + 2 分钟总计时 + 胜负判定。
    /// 场景里只需要有一个 GameManager。
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("配置")]
        public FireDrillConfig config;

        [Header("场景引用")]
        public FireTarget fire;
        public ExtinguisherController extinguisher;
        public QuizManager quiz;
        public UIManager ui;
        public AudioManager audioManager;

        [Header("行为")]
        [Tooltip("排序题打开时，是否暂停 2 分钟总计时（推荐 true，排序题有自己的 30 秒限时）")]
        public bool pauseGlobalTimerDuringQuiz = true;

        public DrillState State { get; private set; } = DrillState.Idle;
        public float Remaining => _global.Remaining;
        public bool QuizPassed { get; private set; }

        [Header("事件")]
        public UnityEvent<DrillState> onStateChanged = new UnityEvent<DrillState>();
        public UnityEvent<float> onGlobalTimerChanged = new UnityEvent<float>();
        public UnityEvent<string> onHint = new UnityEvent<string>();

        readonly CountdownTimer _global = new CountdownTimer();
        bool _started;

        // ---------------------------------------------------------------- 生命周期

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            if (config == null) config = ScriptableObject.CreateInstance<FireDrillConfig>();
        }

        void OnEnable()
        {
            _global.onTick += HandleGlobalTick;
            _global.onFinished += () => Fail("超过总时长 " + config.totalDrillSeconds + " 秒，练习失败");
        }

        void OnDisable()
        {
            _global.onTick -= HandleGlobalTick;
        }

        void Start()
        {
            BindSceneRefs();
            SetState(DrillState.Idle);
            ui?.ShowIntro();
        }

        void Update()
        {
            if (State == DrillState.Idle || State == DrillState.Success || State == DrillState.Failed) return;

            bool paused = State == DrillState.Quiz && pauseGlobalTimerDuringQuiz;
            if (!paused) _global.Tick(Time.deltaTime);
        }

        // ---------------------------------------------------------------- 绑定

        void BindSceneRefs()
        {
            if (fire == null) fire = FindObjectOfType<FireTarget>();
            if (extinguisher == null) extinguisher = FindObjectOfType<ExtinguisherController>();
            if (quiz == null) quiz = FindObjectOfType<QuizManager>();
            if (ui == null) ui = FindObjectOfType<UIManager>();
            if (audioManager == null) audioManager = FindObjectOfType<AudioManager>();

            if (fire != null)
            {
                fire.maxHP = config.fireMaxHP;
                fire.Reset();
                fire.onExtinguished.AddListener(Win);
            }

            if (extinguisher != null)
            {
                extinguisher.onPickedUp.AddListener(OnExtinguisherPickedUp);
                extinguisher.onStageChanged.AddListener(OnExtinguisherStageChanged);
                extinguisher.onHint.AddListener(Hint);
                extinguisher.LockAll();   // 未通过排序题前，灭火器只允许拾取，不允许操作
            }

            if (quiz != null)
            {
                quiz.timeLimit = config.quizSeconds;
                quiz.onPassed.AddListener(OnQuizPassed);
                quiz.onFailed.AddListener(reason => Fail(reason));
            }
        }

        // ---------------------------------------------------------------- 流程

        /// <summary>开场页“开始练习”按钮调用</summary>
        public void BeginPractice()
        {
            if (_started) return;
            _started = true;

            QuizPassed = false;
            fire?.Reset();
            extinguisher?.ResetToStart();
            extinguisher?.LockAll();

            audioManager?.PlayBgm();
            audioManager?.PlayAlarm();

            ui?.HideIntro();
            ui?.ShowHUD();
            Hint(config.hintPickExtinguisher);

            _global.Start(config.totalDrillSeconds);
            SetState(DrillState.Extinguishing);
        }

        void OnExtinguisherPickedUp()
        {
            if (State != DrillState.Extinguishing) return;
            if (QuizPassed) { extinguisher?.UnlockAll(); Hint(config.hintPullPin); return; }

            // 拾取灭火器 → 弹出消防安全步骤排序题
            SetState(DrillState.Quiz);
            extinguisher?.LockAll();
            quiz?.Open();
            ui?.ShowQuiz();
        }

        void OnQuizPassed()
        {
            QuizPassed = true;
            SetState(DrillState.Extinguishing);
            extinguisher?.UnlockAll();
            ui?.HideQuiz();
            Hint(config.hintPullPin);
            audioManager?.PlayUiClick();
        }

        void OnExtinguisherStageChanged(ExtinguisherStage stage)
        {
            ui?.SetStageText(stage switch
            {
                ExtinguisherStage.PinLocked => "步骤 1/3  拔掉保险销",
                ExtinguisherStage.PinRemoved => "步骤 2/3  单击展开灭火口",
                ExtinguisherStage.NozzleOut => "步骤 3/3  对准火焰根部喷射",
                ExtinguisherStage.Spraying => "喷射中…对准火焰根部",
                _ => ""
            });
        }

        public void Win()
        {
            if (State == DrillState.Success || State == DrillState.Failed) return;
            SetState(DrillState.Success);
            _global.Stop();
            extinguisher?.ForceStopSpray();
            ui?.HideHUD();
            ui?.ShowResult(true, "灭火成功！用时 " + (config.totalDrillSeconds - Remaining).ToString("F1") + " 秒");
            audioManager?.PlaySuccess();
        }

        public void Fail(string reason)
        {
            if (State == DrillState.Success || State == DrillState.Failed) return;
            SetState(DrillState.Failed);
            _global.Stop();
            extinguisher?.ForceStopSpray();
            quiz?.Close();
            ui?.HideHUD();
            ui?.HideQuiz();
            ui?.ShowResult(false, reason);
            audioManager?.PlayFail();
        }

        /// <summary>结果页“重新开始”按钮调用</summary>
        public void Restart()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        public void QuitToIntro()
        {
            SetState(DrillState.Idle);
        }

        // ---------------------------------------------------------------- 内部

        void HandleGlobalTick(float remain)
        {
            onGlobalTimerChanged.Invoke(remain);
            ui?.SetTimerText(remain);
        }

        void SetState(DrillState next)
        {
            if (State == next) return;
            State = next;
            onStateChanged.Invoke(next);
        }

        public void Hint(string msg)
        {
            if (string.IsNullOrEmpty(msg)) return;
            onHint.Invoke(msg);
            ui?.SetHintText(msg);
        }
    }
}
