using UnityEngine;

namespace VRFireDrill
{
    /// <summary>
    /// 场景音频总控：开场背景音（BGM）+ 火警 + 喷射 + 成功/失败 + UI 点击。
    /// 音频文件自己从网上下载（.wav/.mp3/.ogg）丢进 Assets/Audio，拖到下面对应槽位即可。
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        [Header("背景音（开场 BGM，循环）")]
        public AudioClip bgmClip;
        [Range(0f, 1f)] public float bgmVolume = 0.35f;
        public bool playBgmOnStart = true;

        [Header("音效")]
        public AudioClip alarmClip;      // 火警铃
        public AudioClip pinClip;        // 拔保险销
        public AudioClip morphClip;      // 灭火口展开
        public AudioClip sprayClip;      // 喷射（循环）
        public AudioClip successClip;    // 通关
        public AudioClip failClip;       // 失败
        public AudioClip uiClickClip;    // UI 点击

        AudioSource _bgm;
        AudioSource _sfx;
        AudioSource _loop;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            _bgm = CreateSource("BGM", bgmVolume, true);
            _sfx = CreateSource("SFX", 1f, false);
            _loop = CreateSource("Loop", 0.6f, true);
        }

        AudioSource CreateSource(string name, float vol, bool loop)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform);
            var src = go.AddComponent<AudioSource>();
            src.playOnAwake = false;
            src.loop = loop;
            src.volume = vol;
            src.spatialBlend = 0f;   // 2D 声音
            return src;
        }

        void Start()
        {
            if (playBgmOnStart) PlayBgm();
        }

        // ------------------------------------------------------------ BGM

        public void PlayBgm()
        {
            if (bgmClip == null || _bgm == null) return;
            _bgm.clip = bgmClip;
            _bgm.loop = true;
            _bgm.volume = bgmVolume;
            if (!_bgm.isPlaying) _bgm.Play();
        }

        public void StopBgm() { if (_bgm != null) _bgm.Stop(); }

        public void DuckBgm(float target = 0.12f, float time = 0.3f)
        {
            if (_bgm == null) return;
            StopAllCoroutines();
            StartCoroutine(Fade(_bgm, target, time));
        }

        public void RestoreBgm(float time = 0.5f)
        {
            if (_bgm == null) return;
            StopAllCoroutines();
            StartCoroutine(Fade(_bgm, bgmVolume, time));
        }

        System.Collections.IEnumerator Fade(AudioSource src, float target, float time)
        {
            float start = src.volume;
            float t = 0f;
            while (t < time)
            {
                t += Time.unscaledDeltaTime;
                src.volume = Mathf.Lerp(start, target, t / time);
                yield return null;
            }
            src.volume = target;
        }

        // ------------------------------------------------------------ 音效

        public void PlayAlarm()
        {
            if (alarmClip != null) _sfx.PlayOneShot(alarmClip, 0.8f);
        }

        public void PlayPin()
        {
            if (pinClip != null) _sfx.PlayOneShot(pinClip, 1f);
        }

        public void PlayMorph()
        {
            if (morphClip != null) _sfx.PlayOneShot(morphClip, 1f);
        }

        public void PlayUiClick()
        {
            if (uiClickClip != null) _sfx.PlayOneShot(uiClickClip, 0.7f);
        }

        public void PlaySuccess()
        {
            StopBgm();
            if (successClip != null) _sfx.PlayOneShot(successClip, 1f);
        }

        public void PlayFail()
        {
            StopBgm();
            if (failClip != null) _sfx.PlayOneShot(failClip, 1f);
        }

        /// <summary>喷射循环音，由 SprayEmitter 控制</summary>
        public void StartSprayLoop()
        {
            if (sprayClip == null || _loop == null) return;
            if (_loop.clip != sprayClip) _loop.clip = sprayClip;
            if (!_loop.isPlaying) _loop.Play();
        }

        public void StopSprayLoop()
        {
            if (_loop != null && _loop.isPlaying) _loop.Stop();
        }
    }
}
