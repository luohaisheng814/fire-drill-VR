using UnityEngine;
using UnityEngine.Events;

namespace VRFireDrill
{
    /// <summary>
    /// 火焰：带生命值。被灭火器喷射"根部"时按 DPS 削减，归零后火焰消失。
    /// 挂在你的火焰预制体根节点上（粒子、灯光都是它的子节点）。
    /// </summary>
    public class FireTarget : MonoBehaviour
    {
        [Header("生命值")]
        public float maxHP = 100f;
        public float currentHP = 100f;

        [Header("根部判定点")]
        [Tooltip("火焰"根部"的空物体：喷射必须瞄准这个点，一般放在火焰底部贴地位置")]
        public Transform rootPoint;

        [Header("视觉")]
        public ParticleSystem fireParticles;
        public ParticleSystem smokeParticles;
        public Light fireLight;
        public float maxLightIntensity = 2f;
        public float minScale = 0.25f;

        [Header("音频")]
        public AudioSource crackleSource;

        [Header("复燃")]
        public float regrowPerSecond = 0f;
        [Tooltip("停止喷射多久后开始复燃")]
        public float regrowDelay = 3f;

        [Header("事件")]
        public UnityEvent onExtinguished = new UnityEvent();
        public UnityEvent<float> onHPChanged = new UnityEvent<float>();

        public bool IsAlive { get; private set; } = true;
        public Vector3 RootPosition => rootPoint != null ? rootPoint.position : transform.position;

        float _timeSinceLastSpray;
        float _baseEmission = 20f;
        float _baseLightIntensity = 2f;

        void Awake()
        {
            if (fireParticles != null) _baseEmission = fireParticles.emission.rateOverTime.constant;
            if (fireLight != null) _baseLightIntensity = maxLightIntensity;
        }

        void Update()
        {
            if (!IsAlive) return;

            _timeSinceLastSpray += Time.deltaTime;
            if (regrowPerSecond > 0f && _timeSinceLastSpray > regrowDelay && currentHP < maxHP)
                SetHP(currentHP + regrowPerSecond * Time.deltaTime);
        }

        public void Reset()
        {
            currentHP = maxHP;
            IsAlive = true;
            _timeSinceLastSpray = 0f;
            gameObject.SetActive(true);
            if (fireParticles != null)
            {
                var em = fireParticles.emission; em.enabled = true;
                fireParticles.Play();
            }
            if (smokeParticles != null) { smokeParticles.Play(); }
            if (crackleSource != null && !crackleSource.isPlaying) crackleSource.Play();
            ApplyVisual();
            onHPChanged.Invoke(currentHP);
        }

        /// <summary>喷射命中时调用，amount 为本次削减的 HP</summary>
        public void ApplyExtinguish(float amount)
        {
            if (!IsAlive || amount <= 0f) return;
            _timeSinceLastSpray = 0f;
            SetHP(currentHP - amount);
        }

        void SetHP(float v)
        {
            currentHP = Mathf.Clamp(v, 0f, maxHP);
            ApplyVisual();
            onHPChanged.Invoke(currentHP);

            if (currentHP <= 0f && IsAlive) Extinguish();
        }

        void Extinguish()
        {
            IsAlive = false;
            if (fireParticles != null)
            {
                var em = fireParticles.emission; em.enabled = false;
                fireParticles.Stop(false, ParticleSystemStopBehavior.StopEmitting);
            }
            if (smokeParticles != null) smokeParticles.Stop(false, ParticleSystemStopBehavior.StopEmitting);
            if (fireLight != null) fireLight.intensity = 0f;
            if (crackleSource != null) crackleSource.Stop();

            // 火焰本体延迟一点再隐藏，让余烟飘散
            Invoke(nameof(HideSelf), 2.5f);
            onExtinguished.Invoke();
        }

        void HideSelf()
        {
            gameObject.SetActive(false);
        }

        void ApplyVisual()
        {
            float t = Mathf.Clamp01(currentHP / Mathf.Max(0.001f, maxHP));

            if (fireParticles != null)
            {
                var em = fireParticles.emission;
                em.rateOverTime = _baseEmission * t;
            }
            if (fireLight != null)
                fireLight.intensity = _baseLightIntensity * t;

            float s = Mathf.Lerp(minScale, 1f, t);
            transform.localScale = new Vector3(s, s, s);
        }
    }
}
