using UnityEngine;

namespace VRFireDrill
{
    /// <summary>
    /// 没有头显时也能在 PC 上验证逻辑：用键盘模拟手柄操作。
    ///   Enter  开始练习
    ///   E      模拟"拾取灭火器"（触发排序题）
    ///   Space  模拟扳机按下（拔销 → 展开灭火口 → 喷射）
    ///   Q Q    快速按两次 Q = 双击放下
    ///   1~6    选择第 N 条步骤
    ///   Backspace 撤销最后一个槽位
    ///   P      一键正确作答
    ///   R      重开
    /// 上线前把 FireDrillConfig.keyboardFallback 关掉即可。
    /// </summary>
    public class DebugKeyboardFallback : MonoBehaviour
    {
        public FireDrillConfig config;

        float _lastQ;
        int _qCount;

        void Update()
        {
            if (config == null || !config.keyboardFallback) return;
            var gm = GameManager.Instance;
            if (gm == null) return;

            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
            {
                gm.BeginPractice();
            }

            if (Input.GetKeyDown(KeyCode.E))
            {
                var ext = FindObjectOfType<ExtinguisherController>();
                ext?.SetGrabbed(true);
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                var ext = FindObjectOfType<ExtinguisherController>();
                ext?.OnAdvancePressed();
            }
            if (Input.GetKeyUp(KeyCode.Space))
            {
                var ext = FindObjectOfType<ExtinguisherController>();
                ext?.OnAdvanceReleased();
            }

            if (Input.GetKeyDown(KeyCode.Q))
            {
                float now = Time.unscaledTime;
                _qCount = (now - _lastQ <= config.doubleClickWindow) ? _qCount + 1 : 1;
                _lastQ = now;
                if (_qCount >= 2)
                {
                    _qCount = 0;
                    var grab = FindObjectOfType<ExtinguisherGrab>();
                    grab?.ForceDrop();
                }
            }

            if (gm.State == DrillState.Quiz)
            {
                var quiz = FindObjectOfType<QuizManager>();
                if (quiz != null)
                {
                    for (int i = 0; i < 9; i++)
                        if (Input.GetKeyDown(KeyCode.Alpha1 + i)) quiz.SelectStep(i);
                    if (Input.GetKeyDown(KeyCode.Backspace)) quiz.RemoveAt(0);
                    if (Input.GetKeyDown(KeyCode.P)) quiz.DebugAutoSolve();
                }
            }

            if (Input.GetKeyDown(KeyCode.R)) gm.Restart();
        }
    }
}
