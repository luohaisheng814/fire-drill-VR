using TMPro;
using UnityEngine;

namespace VRFireDrill
{
    /// <summary>
    /// 所有 World Space 面板的开关与文案。
    /// 四个面板：开场（办公室消防知识练习）/ 排序题 / HUD（倒计时+步骤）/ 结果页。
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("开场页")]
        public GameObject introPanel;
        public TextMeshProUGUI introTitle;
        public TextMeshProUGUI introSubtitle;

        [Header("排序题页")]
        public GameObject quizPanelRoot;

        [Header("HUD")]
        public GameObject hudPanel;
        public TextMeshProUGUI timerText;
        public TextMeshProUGUI stageText;
        public TextMeshProUGUI hintText;

        [Header("结果页")]
        public GameObject resultPanel;
        public TextMeshProUGUI resultTitle;
        public TextMeshProUGUI resultMessage;

        // ------------------------------------------------------------ 开场

        public void ShowIntro()
        {
            if (introPanel != null) introPanel.SetActive(true);
            if (introTitle != null) introTitle.text = "办公室消防知识练习";
            if (introSubtitle != null)
                introSubtitle.text = "拿起灭火器 → 完成消防步骤排序 → 对准火焰根部灭火。\n全程限时 2 分钟。";
        }

        public void HideIntro()
        {
            if (introPanel != null) introPanel.SetActive(false);
        }

        // ------------------------------------------------------------ HUD

        public void ShowHUD() { if (hudPanel != null) hudPanel.SetActive(true); }
        public void HideHUD() { if (hudPanel != null) hudPanel.SetActive(false); }

        public void SetTimerText(float remain)
        {
            if (timerText == null) return;
            int m = Mathf.FloorToInt(remain / 60f);
            int s = Mathf.FloorToInt(remain % 60f);
            timerText.text = $"{m:00}:{s:00}";
            timerText.color = remain <= 20f ? Color.red : Color.white;
        }

        public void SetStageText(string txt) { if (stageText != null) stageText.text = txt; }
        public void SetHintText(string txt) { if (hintText != null) hintText.text = txt; }

        // ------------------------------------------------------------ 排序题

        public void ShowQuiz() { if (quizPanelRoot != null) quizPanelRoot.SetActive(true); }
        public void HideQuiz() { if (quizPanelRoot != null) quizPanelRoot.SetActive(false); }

        // ------------------------------------------------------------ 结果

        public void ShowResult(bool win, string message)
        {
            if (resultPanel != null) resultPanel.SetActive(true);
            if (resultTitle != null)
            {
                resultTitle.text = win ? "通关！" : "练习失败";
                resultTitle.color = win ? new Color(0.35f, 0.85f, 0.45f) : new Color(0.95f, 0.35f, 0.35f);
            }
            if (resultMessage != null) resultMessage.text = message;
        }

        public void HideResult() { if (resultPanel != null) resultPanel.SetActive(false); }
    }
}
