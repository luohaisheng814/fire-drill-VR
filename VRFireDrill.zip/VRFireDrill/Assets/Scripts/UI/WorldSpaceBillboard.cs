using UnityEngine;

namespace VRFireDrill
{
    /// <summary>
    /// 让 World Space 面板始终朝向玩家头部。
    /// 挂在面板根节点上；VR 里 Camera.main 就是头显相机。
    /// </summary>
    public class WorldSpaceBillboard : MonoBehaviour
    {
        public enum Mode { Full, YawOnly }

        public Mode mode = Mode.YawOnly;
        [Tooltip("跟随速度，越大越跟手")]
        public float followSpeed = 6f;
        [Tooltip("面板正面相对朝向的额外偏转（度）")]
        public float yawOffset = 0f;
        [Tooltip("与玩家保持的距离（米），0 = 不自动定位，只旋转")]
        public float distance = 0f;

        Transform _cam;

        void Start()
        {
            if (Camera.main != null) _cam = Camera.main.transform;
        }

        void LateUpdate()
        {
            if (_cam == null)
            {
                if (Camera.main == null) return;
                _cam = Camera.main.transform;
            }

            Vector3 targetPos = _cam.position + _cam.forward * distance;
            if (distance > 0f) transform.position = Vector3.Lerp(transform.position, targetPos, followSpeed * Time.deltaTime);

            Vector3 dir = transform.position - _cam.position;
            Vector3 flat = mode == Mode.YawOnly ? new Vector3(dir.x, 0f, dir.z) : dir;
            if (flat.sqrMagnitude < 0.0001f) return;

            Quaternion look = Quaternion.LookRotation(-flat.normalized);
            look *= Quaternion.Euler(0f, yawOffset, 0f);
            transform.rotation = Quaternion.Slerp(transform.rotation, look, followSpeed * Time.deltaTime);
        }
    }
}
