# VR 办公室消防知识练习 · 完整操作步骤

> 技术栈（你没指定，我按 VR 主流方案定）：**Unity 2022 LTS + OpenXR + XR Interaction Toolkit 2.x**，目标 Meta Quest / Pico 一体机（同时兼容 PCVR）。
> 排序交互：**手柄射线点击依次选择**（可撤销、自动填空位）。
> 图 1 里的 6 条步骤已内置为排序题默认题库（`QuizData.ResetToDefault()`）。

---

## 0. 玩法流程（先看这个）

```
[开场] 面板：办公室消防知识练习 + BGM
   │  点“开始练习”
   ▼
[2 分钟倒计时开始] 火焰在玩家一侧燃烧，HUD 提示“请拿起灭火器”
   │  手柄 Grip 抓起灭火器
   ▼
[弹排序题] “灭火器灭火分为几步骤？请按正确顺序排列” ← 30 秒限时
   │  射线点击 6 条步骤 → 自动填进 1~6 号槽位 → 填满自动判定
   │  ├ 超时 / 答错 → 失败
   │  └ 通过 → 面板关闭
   ▼
[三步操作灭火器]
   第1步 拔保险销（手拉销子 或 按一次扳机）
   第2步 单击扳机 → 灭火口展开（形态转换）
   第3步 灭火口对准火焰根部 → 按住扳机 → 粒子喷雾
   ▼
[火焰 HP 归零 → 消失 → 通关面板]

全局：120 秒内没完成 = 失败；结果页可“重新开始”
```

---

## 1. 装包（Unity 2022 LTS）

1. `Window → Package Manager`，切到 **Unity Registry**，安装：
   - **XR Plugin Management**
   - **OpenXR Plugin**
   - **XR Interaction Toolkit**（装完后 Import "Starter Assets" 和 "XR Device Simulator" 样例，可选但推荐）
   - **TextMeshPro**（首次用 TMP 时会弹窗 Import Essentials，点 Import）
2. `Edit → Project Settings → XR Plug-in Management`：
   - PC 勾 **OpenXR**；Android 页也勾 **OpenXR**（Quest/Pico 走安卓）
   - 进入 **OpenXR → 左侧 OpenXR**：
     - 勾选 **Meta Quest Support**（Quest）或 **PicoXR Support**（Pico）
     - Interaction Profiles 添加 **Oculus Touch Controller Profile** / **Pico Neo3/4 Controller Profile**
   - Render Mode 建议 **Multi Pass**（兼容性最好）
3. `Edit → Project Settings → Player → Android`：Minimum API Level ≥ 29，IL2CPP，ARM64。
4. 把本仓库 `Assets/` 下的 `Scripts/`、`InputActions/` 整个拷进你的工程 `Assets/`。

---

## 2. 准备素材（你自己去网上下载的 4 类）

| 素材 | 放哪 | 说明 |
|---|---|---|
| 办公室场景模型 | `Assets/Models/Office/` | SketchFab / Unity Asset Store 搜 "Office Interior"、"Office Room" |
| 灭火器模型 | `Assets/Models/Extinguisher/` | 必须是一个**可拆的子层级**：本体 + 保险销 + 喷管（或至少本体一个 Mesh） |
| 火焰 / 烟雾粒子 | `Assets/VFX/` | Asset Store 搜 "Fire Particle System"、"Stylized Fire"；喷雾用白色细颗粒就行 |
| 音频 | `Assets/Audio/` | BGM（办公室环境音/轻音乐）、火警铃、拔销咔哒、金属展开、喷射嘶声、成功、失败、UI 点击 |

> **没有素材也能先跑通逻辑**：菜单 `VR Fire Drill → 1. 创建占位办公室 / 2. 创建火焰点 / 3. 把选中物体做成灭火器`，会生成占位几何体 + 挂好全部脚本，之后再替换 Mesh 和粒子。

---

## 3. 搭 XR 玩家（5 分钟）

1. 菜单 `GameObject → XR → XR Origin (VR)`（**不要**用 Room-Scale 以外的老 XR Rig）。
2. 场景里会自动出现：
   - `XR Interaction Manager`（全场景**只能有一个**）
   - `XR Origin` → `Camera Offset` → `Main Camera`
   - `LeftHand Controller` / `RightHand Controller`
3. 给两只手各加一个 **XR Ray Interactor**（或直接用 Starter Assets 里的 `XR Interaction Setup`）：
   - 左手：`LeftHand Controller` 上挂 **Near-Far Interactor**（或 XRRayInteractor + XRDirectInteractor 二选一组合）
   - 右手：同上。**至少一只手要有 Ray Interactor，否则点不了 UI**
4. 选中 `XR Origin`，Add Component → **Input Action Manager**，把 `Assets/InputActions/FireDrillInputActions.inputactions` 拖进 **Action Assets** 列表。
5. 左手 Controller 的 `XR Controller (Action-based)` 组件里，把 Position/Rotation/Select/Activate/UI Press 全部指向刚才那份 inputactions 里的 **XRI LeftHand** 同名 Action；右手同理指向 **XRI RightHand**。
6. `Main Camera` 上的 Tracked Pose Driver 指向 **XRI Head / Center Eye**（如果用 XRI 默认资源就跳过这步）。

---

## 4. 搭灭火器（核心）

### 4.1 层级结构（照着建）

```
Extinguisher (Rigidbody + BoxCollider + ExtinguisherGrab + ExtinguisherController + SprayEmitter)
├── Body               ← 你的灭火器 Mesh
├── SafetyPin          ← 小圆柱 Mesh + Rigidbody + XR Grab Interactable + SafetyPin
├── NozzleGroup        ← 喷管/灭火口 Mesh，初始 SetActive(false)
│   ├── NozzleTip      ← 空物体！它的蓝轴 Z+ 就是喷射方向
│   └── Spray_Particles← 粒子系统（白色锥形喷雾）
└── Spray_Particles(可选，放本体上也行)
```

> 快捷方式：把灭火器模型拖进场景 → 选中它 → 菜单 `VR Fire Drill → 3. 把选中物体做成灭火器`，脚本和子物体会自动生成，你只需替换 Mesh。

### 4.2 组件参数

**ExtinguisherGrab**（继承 XRGrabInteractable，取代默认的 Grab Interactable）
- `Attach Transform`：新建一个空物体放在灭火器把手处，拖进来（握持手感）
- `Movement Type`：**Kinematic**（粘手更稳）或 Instant
- `Drop Action`：拖 `FireDrillInputActions / XRI RightHand / Drop Extinguisher`（绑的是 **A / X 键**）
- `Double Click Window`：0.4
- `Sticky Grab`：**勾选**（= 松手不掉，双击才掉）
- `Controller`：拖自身的 `ExtinguisherController`

**ExtinguisherController**
- `Safety Pin` → SafetyPin 物体
- `Nozzle Group` → NozzleGroup（初始隐藏的那个）
- `Nozzle Tip` → NozzleTip 空物体
- `Spray` → SprayEmitter
- `Advance Action` → `FireDrillInputActions / XRI RightHand / Activate`（**扳机**）
- `Hold To Spray`：勾选 = 按住喷、松手停；取消 = 点一下开、再点一下关
- `Allow Button To Pull Pin`：建议勾选（新手不会手拔时用扳机拔）
- 可选：`Hose Animator` → 给 NozzleGroup 做个展开动画（Deploy / Retract 两个 Trigger）

**SprayEmitter**
- `Nozzle Tip` → NozzleTip
- `Spray Particles` → 你的喷雾粒子
- `Target` → 场景里的 FireTarget
- `Max Range` 3.5、`Min Range` 0.3、`Root Aim Angle` 25、`Root Damage Per Second` 45、`Off Root Damage Factor` 0.15
- `Blocking Layers`：勾选会挡住喷雾的层（墙、桌子）；**不要**勾 UI 层

**SafetyPin**
- `Home Point`：复制一个空物体放在销子初始位置，拖进来（判定"拉出多远算拔掉"）
- `Pull Distance`：0.12（米）
- 它自己挂普通 `XR Grab Interactable`（**不要**用 ExtinguisherGrab，销子要松手即掉）

### 4.3 关键提醒：喷射方向
`NozzleTip` 的 **蓝色箭头（Z 轴）必须指向前方**。在 Scene 视图里选中 NozzleTip，用移动工具看蓝轴朝向，不对就旋转它。所有"对准根部"的判定都基于这个方向。

---

## 5. 搭火焰

1. 把火焰粒子预制体放到 **玩家放置手柄的位置旁边**（XR Origin 一侧，距离 1.5–2.5 米，地面高度）。
2. 根节点挂 `FireTarget`：
   - `Root Point`：在火焰**底部贴地**处建一个空物体（这是"根部"，最关键）
   - `Fire Particles` / `Smoke Particles` / `Fire Light`：拖进去
   - `Max HP` 100、`Regrow Per Second` 0（想加点难度设 3~5）
3. 火焰根节点加个 `Sphere Collider`（半径 0.5，Is Trigger 也行），方便以后做"靠近被烧伤"。
4. 挂 `AudioSource` 放火焰燃烧声，拖到 `Crackle Source`，勾 Loop + Spatial Blend = 1（3D 声音）。

---

## 6. 搭 UI（World Space Canvas）

1. `GameObject → UI → Canvas`，改名 `UI_Intro`：
   - Render Mode：**World Space**
   - 挂 **Tracked Device Graphic Raycaster**（替换默认 Graphic Raycaster）
   - 挂 **WorldSpaceBillboard**（脚本已提供，Mode 选 YawOnly）
   - 位置：玩家正前方 1.2–1.5 米，高 1.4 米，Scale 0.001~0.002
   - 内容：标题「办公室消防知识练习」+ 副标题 +「开始练习」按钮
2. 同样方式建 `UI_Quiz`、`UI_HUD`、`UI_Result`：
   - **UI_Quiz**：`QuizManager` 面板根物体；里面要有
     - `QuestionText`（TMP）、`TimerText`（TMP）、`FeedbackText`（TMP）、`ProgressText`（TMP）
     - 一个 `StepContainer`（挂 Vertical Layout Group）和 `SlotContainer`（挂 Vertical Layout Group）
     - 做两个预制体：`StepItem`（带 Button + TMP + Image，挂 `QuizStepItem`）、`AnswerSlot`（带 Button + TMP + Image，挂 `QuizAnswerSlot`），分别拖到 QuizManager 的 `Step Item Prefab` / `Slot Prefab`
   - **UI_HUD**：`TimerText`、`StageText`、`HintText`（都非交互）
   - **UI_Result**：`ResultTitle`、`ResultMessage` +「重新开始」按钮
3. **必须有 EventSystem**：`GameObject → UI → Event System`，把默认的 `Standalone Input Module` **删掉**，Add Component → **XR UI Input Module**。
4. 每个需要交互的 Canvas 都要有 `Tracked Device Graphic Raycaster`。

---

## 7. 搭总控

1. 空物体 `GameManager` 挂 `GameManager` + `DebugKeyboardFallback`。
2. Project 右键 `Create → VR Fire Drill → Config` 生成 `FireDrillConfig` 资源，拖到 GameManager 的 `Config`：
   - Total Drill Seconds **120**、Quiz Seconds **30**
   - Fire Max HP 100、Root Damage Per Second 45（想快点灭就调大，45 → 约 2.2 秒喷灭）
3. Project 右键 `Create → VR Fire Drill → Fire Safety Quiz` 生成题库，拖到 `QuizManager.data`（列表顺序 = 正确顺序，可自己增删）。
4. 空物体 `UIManager` 挂 `UIManager`，把四个面板和所有 TMP 拖进去。
5. 空物体 `AudioManager` 挂 `AudioManager`，把下载的音频拖到对应槽位。
6. 空物体 `QuizManager` 挂 `QuizManager`，填 `Panel`、`questionText`、`timerText`、`feedbackText`、`progressText`、两个预制体与容器。
7. **按钮绑定**（在 Button 的 OnClick 里选）：
   - 开场「开始练习」→ `GameManager.BeginPractice()`
   - 结果页「重新开始」→ `GameManager.Restart()`
   - （排序题的条目/槽位是运行时自动生成的，不用手绑）
8. 串事件（也可在 Inspector 的 UnityEvent 里拖）：
   - `FireTarget.onExtinguished` → `GameManager.Win()`
   - `ExtinguisherGrab.onPickedUp` → `ExtinguisherController.SetGrabbed(true)`（脚本内部已做，只需确认 Controller 引用已拖）
   - `QuizManager.onPassed` → `GameManager`（内部已绑）
   - `QuizManager.onFailed` → `GameManager`（内部已绑）

> 快捷方式：菜单 `VR Fire Drill → 4. 创建总控与配置` 会一次性建好 4 个 Manager 物体。

---

## 8. 输入映射总表

| 功能 | 按键 | Action |
|---|---|---|
| 抓起灭火器 | Grip（侧握键） | XRI RightHand / Select |
| 推进步骤（拔销 → 展开灭火口 → 喷射） | Trigger（扳机） | XRI RightHand / Activate |
| 放下灭火器 | **双击** A / X | XRI RightHand / Drop Extinguisher |
| 点 UI（排序题、按钮） | Trigger 射线 | XRI *Hand / UI Press |
| 拔保险销（物理方式） | 另一只手 Grip 抓住销子往外拉 | — |

> 想换键：打开 `FireDrillInputActions.inputactions` 双击编辑，改 Binding 路径即可（`primaryButton` = A/X，`secondaryButton` = B/Y，`gripPressed` = 侧握键，`triggerPressed` = 扳机）。

---

## 9. 无头显也能测（强烈建议先测逻辑）

`FireDrillConfig.keyboardFallback = true`（默认开），在 PC 上按：

| 键 | 作用 |
|---|---|
| Enter | 开始练习 |
| E | 模拟抓起灭火器（弹出排序题） |
| 1~6 | 依次选择步骤 |
| Backspace | 撤销 |
| P | 一键正确作答（最快走通流程） |
| Space（按住） | 扳机：拔销 → 展开灭火口 → 喷射 |
| Q Q（快按两下） | 双击放下 |
| R | 重开 |

上线前把 `keyboardFallback` 设为 false。

---

## 10. 常见坑

| 现象 | 原因 / 解决 |
|---|---|
| 抓起来松手就掉 | `ExtinguisherGrab.stickyGrab` 没勾，或 `dropAction` 没绑 |
| 双击没反应 | A/X 键没绑到 `Drop Extinguisher`；或 `doubleClickWindow` 太小 |
| 喷了但火不掉血 | ① `NozzleTip` 蓝轴没朝前 ② 距离超过 `Max Range` ③ `RootPoint` 放太高（要在火焰底部）④ `BlockingLayers` 把火焰自己挡住了 |
| 点不了 UI | Canvas 缺 `Tracked Device Graphic Raycaster` / EventSystem 用的是 Standalone 而非 XR UI Input Module / 手上没有 Ray Interactor |
| 排序题不弹 | `ExtinguisherGrab.controller` 没拖，或 GameManager 没找到 ExtinguisherController |
| 2 分钟一到就失败 | 这是设计；调 `FireDrillConfig.totalDrillSeconds` |
| 一抓起灭火器的同时触发了 UI 点击 | 把该手 Ray Interactor 的 Raycast Mask 去掉 Default 层，或喷射时禁用射线（进阶） |

---

## 11. 目录结构

```
Assets/
├── Scripts/
│   ├── Core/      FireDrillConfig.cs  CountdownTimer.cs  GameManager.cs
│   ├── Extinguisher/  ExtinguisherGrab.cs  ExtinguisherController.cs
│   │                  SafetyPin.cs  SprayEmitter.cs
│   ├── Fire/      FireTarget.cs
│   ├── Quiz/      QuizData.cs  QuizManager.cs  QuizStepItem.cs  QuizAnswerSlot.cs
│   ├── UI/        UIManager.cs  WorldSpaceBillboard.cs
│   ├── Audio/     AudioManager.cs
│   ├── Utils/     DebugKeyboardFallback.cs
│   └── Editor/    FireDrillSetupWizard.cs
├── InputActions/  FireDrillInputActions.inputactions
├── Models/        （你下载：Office / Extinguisher）
├── VFX/           （你下载：火焰 / 喷雾粒子）
└── Audio/         （你下载：BGM / 火警 / 拔销 / 喷射 / 成功 / 失败 / UI）
```
